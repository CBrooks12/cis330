#include "sink.h"

sink::sink()
{

}

sink::~sink()
{
	
}
