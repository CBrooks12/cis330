#include "sink.h"

sink::sink()
{
	img1 = NULL;
	img2 = NULL;
}

sink::~sink()
{
	
}
